from .console import Console


__title__ = 'console'
__author__ = 'l3alr0g'