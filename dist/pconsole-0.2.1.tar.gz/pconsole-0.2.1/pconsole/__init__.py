from .console import Console
from .version import __version__ as v

__title__ = 'console'
__author__ = 'l3alr0g'
__version__ = v